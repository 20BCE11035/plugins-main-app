## 0.1.0+4

* Updates example code for `use_build_context_synchronously` lint.
* Updates minimum Flutter version to 3.0.

## 0.1.0+3

* Changes XTypeGroup initialization from final to const.
* Updates minimum Flutter version to 2.10.

## 0.1.0+2

* Minor fixes for new analysis options.

## 0.1.0+1

* Removes unnecessary imports.
* Fixes library_private_types_in_public_api, sort_child_properties_last and use_key_in_widget_constructors
  lint warnings.

## 0.1.0

* Initial Windows support.
