# local_auth_example

Demonstrates how to use the local_auth plugin.
