# file_selector_example

Demonstrates how to use the file_selector plugin.
