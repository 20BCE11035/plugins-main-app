## NEXT

* Updates example code for `use_build_context_synchronously` lint.
* Updates minimum Flutter version to 3.0.

## 0.9.1

* Adds `getDirectoryPaths` implementation.

## 0.9.0+1

* Changes XTypeGroup initialization from final to const.
* Updates minimum Flutter version to 2.10.

## 0.9.0

* Moves source to flutter/plugins.

## 0.0.3

* Adds Dart implementation for in-package method channel.

## 0.0.2+1

* Updates README

## 0.0.2

* Updates SDK constraint to signal compatibility with null safety.

## 0.0.1

* Initial Linux implementation of `file_selector`.
