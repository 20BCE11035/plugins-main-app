## NEXT

* Updates example code for `use_build_context_synchronously` lint.
* Updates minimum Flutter version to 3.0.

## 0.5.0+2

* Changes XTypeGroup initialization from final to const.
* Updates minimum Flutter version to 2.10.

## 0.5.0+1

* Updates README for endorsement.

## 0.5.0

* Initial iOS implementation of `file_selector`.
