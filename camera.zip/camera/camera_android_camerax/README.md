# camera_android_camerax

An implementation of the camera plugin on Android using CameraX.
