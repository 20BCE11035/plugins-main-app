# path_provider_example

Demonstrates how to use the path_provider plugin.
