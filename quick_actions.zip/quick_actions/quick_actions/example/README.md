# quick_actions_example

Demonstrates how to use the quick_actions plugin.
