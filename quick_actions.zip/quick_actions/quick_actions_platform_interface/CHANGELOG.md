## NEXT

* Updates minimum Flutter version to 3.0.

## 1.0.3

* Updates imports for `prefer_relative_imports`.
* Updates minimum Flutter version to 2.10.

## 1.0.2

* Removes dependency on `meta`.

## 1.0.1

* Updates code for analyzer changes.
* Update to use the `verify` method introduced in plugin_platform_interface 2.1.0.

## 1.0.0

* Initial release of quick_actions_platform_interface
