# quick\_actions\_ios

The iOS implementation of [`quick_actions`][1].

## Usage

This package is [endorsed][2], which means you can simply use `quick_actions`
normally. This package will be automatically included in your app when you do.

## Contributing

If you would like to contribute to the plugin, check out our [contribution guide][3].

[1]: https://pub.dev/packages/quick_actions
[2]: https://flutter.dev/docs/development/packages-and-plugins/developing-packages#endorsed-federated-plugin
[3]: https://github.com/flutter/plugins/blob/main/CONTRIBUTING.md
