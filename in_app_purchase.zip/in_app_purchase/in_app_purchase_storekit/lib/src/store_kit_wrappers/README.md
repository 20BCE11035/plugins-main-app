# store_kit_wrappers

This exposes Dart endpoints through to the
[StoreKit](https://developer.apple.com/documentation/storekit) APIs. Can be used
as an alternative to [in_app_purchase](../in_app_purchase/README.md).