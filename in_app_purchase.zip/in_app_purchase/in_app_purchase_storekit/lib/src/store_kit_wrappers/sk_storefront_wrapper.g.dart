// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'sk_storefront_wrapper.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

SKStorefrontWrapper _$SKStorefrontWrapperFromJson(Map json) =>
    SKStorefrontWrapper(
      countryCode: json['countryCode'] as String,
      identifier: json['identifier'] as String,
    );

Map<String, dynamic> _$SKStorefrontWrapperToJson(
        SKStorefrontWrapper instance) =>
    <String, dynamic>{
      'countryCode': instance.countryCode,
      'identifier': instance.identifier,
    };
