## NEXT

* Updates minimum Flutter version to 3.0.

## 1.3.2

* Updates imports for `prefer_relative_imports`.
* Updates minimum Flutter version to 2.10.
* Removes unnecessary imports.

## 1.3.1

* Update to use the `verify` method introduced in plugin_platform_interface 2.1.0.

## 1.3.0

* Added new `PurchaseStatus` named `canceled` to distinguish between an error and user cancellation. 

## 1.2.0

* Added `toString()` to `IAPError`

## 1.1.0

* Added `currencySymbol` in ProductDetails.

## 1.0.1

* Fixed `Restoring previous purchases` link.

## 1.0.0

* Initial open-source release.
