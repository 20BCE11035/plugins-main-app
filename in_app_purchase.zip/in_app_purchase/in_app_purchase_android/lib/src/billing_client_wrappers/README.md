# billing_client_wrappers

This exposes a way Dart endpoints through to [Google Play Billing
Library](https://developer.android.com/google/play/billing/billing_library_overview).
Can be used as an alternative to
[in_app_purchase](../in_app_purchase/README.md).